import bpy

bl_info = {
    "name": "AutoLabel 1.0",
    "author": "Fran Daza",
    "version": (1, 3, 1),
    "blender": (3, 0, 0),
    "location": "Sequencer > Add",
    "description": "Creates customized text strips in the sequencer",
    "warning": "",
    "doc_url": "",
    "category": "Sequencer",
}

# Main function
def add_text_strips_for_scenes(sequence_name, prefix, increment, destination_channel,
                               reference_channels, location_x, location_y,
                               font_size, use_box, text_color):
    sequence_editor = bpy.context.scene.sequence_editor
    if not sequence_editor:
        bpy.context.scene.sequence_editor_create()
        sequence_editor = bpy.context.scene.sequence_editor

    # Convert reference channels from string to integer list
    reference_channels = [int(ch.strip()) for ch in reference_channels.split(",") if ch.strip().isdigit()]

    # Filter strips based on reference channels
    strips = [
        strip for strip in sequence_editor.sequences_all 
        if strip.channel in reference_channels and strip.frame_start >= 0
    ]
    strips = sorted(strips, key=lambda s: s.frame_start)  # Sort by frame_start

    for i, strip in enumerate(strips, start=1):
        shot_number = f"{i * increment:03d}"  # Incremental numbering
        text_name = f"{sequence_name}_{prefix}{shot_number}"  # Customized format
        frame_start = int(strip.frame_start)
        frame_end = int(strip.frame_final_end)

        # Create text strip
        text_strip = sequence_editor.sequences.new_effect(
            name=text_name,
            type='TEXT',
            channel=destination_channel,
            frame_start=frame_start,
            frame_end=frame_end,
        )
        # Configure text strip
        text_strip.text = text_name
        text_strip.font_size = font_size
        text_strip.use_box = use_box
        text_strip.box_color = (0, 0, 0, 0.8) if use_box else (0, 0, 0, 0)
        text_strip.color = text_color  # Assign color
        text_strip.location = (location_x, location_y)  # Text position
        text_strip.blend_type = 'ALPHA_OVER'

        print(f"Created text: {text_name} ({frame_start}-{frame_end}) on channel {destination_channel}")

# Operator class
class AddTextStripsOperator(bpy.types.Operator):
    bl_idname = "sequencer.add_text_strips"
    bl_label = "AutoLabel 1.0"
    bl_description = "Generates customized text strips in the sequencer"

    # Properties
    sequence_name: bpy.props.StringProperty(
        name="Sequence Name",
        description="Enter the sequence name",
        default="S500_Test"
    )
    prefix: bpy.props.StringProperty(
        name="Shot Prefix",
        description="Prefix before the shot number",
        default="C"
    )
    increment: bpy.props.IntProperty(
        name="Shot Number Increment",
        description="Difference between shot numbers (e.g., 10, 100)",
        default=10,
        min=1
    )
    destination_channel: bpy.props.IntProperty(
        name="Destination Channel",
        description="Channel where strips will be created",
        default=6,
        min=1
    )
    reference_channels: bpy.props.StringProperty(
        name="Reference Channels",
        description="Channels to use as reference, separated by commas (e.g., 1,2,3)",
        default="1"
    )
    location_x: bpy.props.FloatProperty(
        name="Position X",
        description="Text position on X-axis",
        default=0.09,
        min=0.0,
        max=1.0
    )
    location_y: bpy.props.FloatProperty(
        name="Position Y",
        description="Text position on Y-axis",
        default=0.05,
        min=0.0,
        max=1.0
    )
    font_size: bpy.props.IntProperty(
        name="Font Size",
        description="Font size of the text strips",
        default=30,
        min=1
    )
    use_box: bpy.props.BoolProperty(
        name="Shadow Box",
        description="Whether the text has a shadow box",
        default=True
    )
    text_color: bpy.props.FloatVectorProperty(
        name="Text Color",
        description="Text color in RGBA format",
        subtype='COLOR',
        size=4,
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0,
        max=1.0
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        add_text_strips_for_scenes(
            self.sequence_name, self.prefix, self.increment,
            self.destination_channel, self.reference_channels,
            self.location_x, self.location_y, self.font_size,
            self.use_box, self.text_color
        )
        self.report({'INFO'}, "Text strips added successfully.")
        return {'FINISHED'}

# Add to sequencer menu
def menu_func(self, context):
    self.layout.operator(AddTextStripsOperator.bl_idname, text="AutoLabel 1.0")

# Register and unregister
def register():
    bpy.utils.register_class(AddTextStripsOperator)
    bpy.types.SEQUENCER_MT_add.append(menu_func)

def unregister():
    bpy.utils.unregister_class(AddTextStripsOperator)
    bpy.types.SEQUENCER_MT_add.remove(menu_func)

if __name__ == "__main__":
    register()
